#include "threads/vaddr.h"
#include "threads/thread.h"
#include "threads/interrupt.h"
#include "process.h"

void exit (int status)
{
  struct thread *cur = thread_current();
  cur->exit_code = status;
  thread_exit();
}

void check_ptr (const void *ptr)
{
  if (!is_user_vaddr(ptr) || ptr < ((void *) 0x08048000))
  {
    exit(11);
  }
}

void extract_args(struct intr_frame *f, int *arg, int argsLimit)
{
  int i;
  int *ptr;
  for (i = 0; i < argsLimit; i++)
  {
    ptr = (int *) f->esp + i + 1;
    check_ptr((const void *) ptr);
    arg[i] = *ptr;
  }
}

