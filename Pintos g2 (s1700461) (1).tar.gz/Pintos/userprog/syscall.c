#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
// #include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "lib/user/syscall.h"
#include "threads/init.h"
#include "process.h"
#include "lib/stdio.h"
// #include "threads/vaddr.h"
#include "filesys/filesys.h"

// Include custom helpers file
#include "./helpers.c"

static void syscall_handler(struct intr_frame *);

void halt (void) NO_RETURN;
void exit (int status) NO_RETURN;
pid_t exec (const char *file);
int wait (pid_t);
bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
int filesize (int fd);
int read (int fd, void *buffer, unsigned length);
int write (int fd, const void *buffer, unsigned length);
void seek (int fd, unsigned position);
unsigned tell (int fd);
void close (int fd);

void syscall_init(void)
{
  intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame *f UNUSED)
{
  // uint32_t *p = f->esp;
  uint32_t *user_esp = f->esp;
  int arg[5];

  switch (*user_esp) {

    case SYS_HALT:
    {
      shutdown_power_off();      
      break;
    }

    case SYS_EXIT:
    {
      extract_args(f, &arg[0], 1);
      exit(arg[0]);
      // thread_exit();
      break;
    }

    case SYS_WRITE: {
      int fd =*(int *)(f->esp + 4);
      void *buffer = *(char**) (f->esp + 8);
      unsigned size = *(unsigned *)(f->esp + 12);
      if(fd==STDOUT_FILENO) {
        putbuf((const char*)buffer, (unsigned )size);
      }
      else {
        printf("sys_write does not support fd output\n");
      }
      break;
    }

    case SYS_CREATE: {
      extract_args(f, &arg[0], 2);
      bool success = filesys_create((const char *)arg[0], arg[1]);
      if (!success)
      {
        exit(-1);
      }
      break;
    }

    case SYS_EXEC: {
      f->eax = exec((const char *)*(user_esp + 1));
      break;
    }

    case SYS_WAIT: {
      f->eax = wait(*(user_esp + 1));
      break;
    }

    default:
      // 0 - SYS_HALT
      // 1 - SYS_EXIT
      // 2 - SYS_EXEC
      // 3 - SYS_WAIT
      // 4 - SYS_CREATE
      // 5 - SYS_REMOVE
      // 6 - SYS_OPEN
      // 7 - SYS_FILESIZE
      // 8 - SYS_READ
      // 9 - SYS_WRITE
      // 10 - SYS_SEEK
      // 11 - SYS_TELL
      // 12 - SYS_CLOSE
      printf("SYS_CALL (%d) is not implemented\n", *user_esp);
      thread_exit();
      break;
  }
}

pid_t exec (const char *cmd_line)
{
 if(cmd_line == NULL) exit(-1);
 void * argv = (void *)cmd_line;
 check_ptr(argv);
 pid_t id = process_execute(cmd_line);
 return id;
}

int wait (pid_t pid)
{
  return process_wait(pid);
}
